# Liste des tâches pour le projet Inception

## Analyse et préparation
- [x] Analyser le fichier PDF du sujet
- [x] Extraire et structurer les exigences du projet
- [x] Planifier les tâches et les livrables

## Structure du projet
- [x] Créer l'arborescence des dossiers selon les spécifications
- [x] Créer le Makefile principal
- [x] Configurer le fichier .env pour les variables d'environnement
- [x] Préparer les fichiers secrets (sans les mots de passe réels)

## Configuration des services

### NGINX
- [x] Créer le Dockerfile pour NGINX
- [x] Configurer NGINX pour TLS 1.2/1.3
- [x] Configurer la redirection vers WordPress
- [x] Préparer les certificats SSL

### MariaDB
- [x] Créer le Dockerfile pour MariaDB
- [x] Configurer MariaDB pour WordPress
- [x] Préparer les scripts d'initialisation de la base de données

### WordPress
- [x] Créer le Dockerfile pour WordPress
- [x] Configurer PHP-FPM
- [x] Préparer les scripts d'installation de WordPress

## Docker Compose
- [x] Créer le fichier docker-compose.yml
- [x] Configurer les volumes persistants
- [x] Configurer le réseau Docker
- [x] Définir les dépendances entre services

## Bonus (optionnels)
- [ ] Configurer Redis cache pour WordPress
- [ ] Mettre en place un serveur FTP
- [ ] Créer un site web statique simple
- [ ] Configurer Adminer
- [ ] Ajouter un service supplémentaire au choix

## Documentation et finalisation
- [ ] Documenter l'architecture du projet
- [ ] Documenter les procédures d'installation et d'utilisation
- [ ] Vérifier la conformité avec les exigences du sujet
- [ ] Préparer les fichiers à remettre
