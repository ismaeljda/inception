# Exigences du Projet Inception

## Résumé du Projet
- Document relatif à un exercice d'Administration Système
- Version: 3.2
- Nom du projet: Inception

## Objectif Principal
Mettre en place une infrastructure de services à l'aide de Docker Compose, comprenant plusieurs conteneurs interconnectés avec une gestion sécurisée des données et des communications.

## Exigences Techniques Principales

### Infrastructure Docker
- Utilisation obligatoire de Docker Compose
- Chaque service doit fonctionner dans son propre conteneur dédié
- Les conteneurs doivent être construits à partir d'une image Alpine Linux ou Debian Bullseye
- Chaque service doit avoir son propre Dockerfile
- Les Dockerfiles doivent être appelés dans le docker-compose.yml via le dossier srcs

### Services Obligatoires
1. **NGINX**:
   - Seul point d'entrée de l'infrastructure
   - Accessible uniquement via le port 443 (HTTPS)
   - Utilisation des protocoles TLSv1.2 ou TLSv1.3
   - Doit rediriger vers le service WordPress

2. **WordPress**:
   - Avec son propre serveur web (pas NGINX)
   - Configuration avec php-fpm
   - Installation et configuration de WordPress

3. **MariaDB**:
   - Service de base de données
   - Volume dédié pour la persistance des données

### Volumes
- Un volume pour la base de données
- Un volume pour les fichiers du site WordPress

### Réseau
- Mise en place d'un réseau Docker pour connecter les conteneurs
- NGINX comme seul point d'entrée (port 443)

### Sécurité
- Utilisation obligatoire de variables d'environnement
- Recommandation d'utiliser un fichier .env pour stocker les variables
- Utilisation de Docker secrets pour les informations confidentielles
- Aucune information d'identification ne doit être stockée publiquement (pas dans Git)

## Structure des Dossiers
```
./
├── Makefile
├── secrets/
│   ├── credentials.txt
│   ├── db_password.txt
│   └── db_root_password.txt
└── srcs/
    ├── docker-compose.yml
    ├── .env
    └── requirements/
        ├── bonus/
        ├── mariadb/
        │   ├── conf/
        │   ├── Dockerfile
        │   ├── .dockerignore
        │   └── tools/
        ├── nginx/
        │   ├── conf/
        │   ├── Dockerfile
        │   ├── .dockerignore
        │   └── tools/
        ├── tools/
        └── wordpress/
```

## Bonus (Optionnels)
- Redis cache pour WordPress
- Serveur FTP pointant vers le volume WordPress
- Site web statique simple (dans n'importe quel langage sauf PHP)
- Adminer
- Un service supplémentaire au choix (à justifier)

## Règles de Soumission
- Tout le travail doit être soumis dans un dépôt Git
- Seul le contenu du dépôt sera évalué
- Vérification des noms de dossiers et fichiers

## Remarques Importantes
- La partie bonus ne sera évaluée que si la partie obligatoire est parfaitement complétée
- Pour les bonus, des ports supplémentaires peuvent être ouverts selon les besoins
