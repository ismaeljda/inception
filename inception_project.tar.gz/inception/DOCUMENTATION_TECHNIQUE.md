# Documentation technique du projet Inception

## Architecture détaillée

### Vue d'ensemble
Le projet Inception met en place une infrastructure Docker composée de trois services principaux, chacun fonctionnant dans son propre conteneur :

1. **NGINX** : Serveur web et proxy inverse, point d'entrée unique de l'infrastructure
2. **WordPress** : Application web avec PHP-FPM
3. **MariaDB** : Système de gestion de base de données

### Schéma d'architecture
```
                    ┌─────────────┐
                    │             │
 HTTPS (443) ───────►    NGINX    │
                    │             │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │             │
                    │  WordPress  │
                    │  (PHP-FPM)  │
                    │             │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │             │
                    │   MariaDB   │
                    │             │
                    └─────────────┘
```

### Flux de données
1. Les requêtes client arrivent sur le port 443 (HTTPS) et sont traitées par NGINX
2. NGINX redirige les requêtes PHP vers le conteneur WordPress via FastCGI
3. WordPress communique avec MariaDB pour les opérations de base de données
4. Les réponses suivent le chemin inverse jusqu'au client

## Détails techniques des services

### NGINX
- **Image de base** : Debian Bullseye
- **Configuration** :
  - TLS 1.2/1.3 avec certificats auto-signés
  - Proxy inverse vers WordPress via FastCGI
  - Point d'entrée unique sur le port 443
- **Volumes** : Partage le volume WordPress pour servir les fichiers statiques

### WordPress
- **Image de base** : Debian Bullseye
- **Composants** :
  - PHP 7.4 avec PHP-FPM
  - WordPress dernière version
  - Extensions PHP nécessaires (mysql, curl, gd, etc.)
- **Configuration** :
  - PHP-FPM écoutant sur le port 9000
  - Configuration WordPress via variables d'environnement
- **Volumes** : Volume persistant pour les fichiers WordPress

### MariaDB
- **Image de base** : Debian Bullseye
- **Configuration** :
  - Optimisations de performance et sécurité
  - Création automatique de la base WordPress
  - Utilisateur dédié pour WordPress
- **Volumes** : Volume persistant pour les données de la base

## Gestion des données

### Volumes persistants
- **mariadb_data** : Stocke les fichiers de base de données
- **wordpress_data** : Stocke les fichiers de l'application WordPress

### Variables d'environnement
Toutes les configurations sensibles sont gérées via des variables d'environnement stockées dans le fichier `.env` :
- Informations de connexion à la base de données
- Paramètres WordPress
- Noms de domaine et chemins

### Sécurité
- Isolation complète des services dans des conteneurs séparés
- Communication réseau limitée entre les conteneurs
- Stockage sécurisé des secrets
- HTTPS obligatoire avec TLS 1.2/1.3

## Réseau Docker
- Réseau bridge dédié pour la communication entre conteneurs
- Isolation du réseau externe
- Exposition minimale des ports (uniquement 443)

## Déploiement et maintenance

### Commandes Makefile
- `make up` : Construction et démarrage des conteneurs
- `make down` : Arrêt des conteneurs
- `make clean` : Nettoyage des conteneurs, réseaux et volumes
- `make fclean` : Nettoyage complet (conteneurs, images, volumes, réseaux)
- `make re` : Reconstruction complète de l'infrastructure
- `make logs` : Affichage des logs des conteneurs

### Sauvegarde et restauration
Pour sauvegarder les données :
```bash
# Sauvegarde de la base de données
docker exec mariadb mysqldump -u root -p<password> wordpress > backup.sql

# Sauvegarde des fichiers WordPress
docker cp wordpress:/var/www/html ./wordpress_backup
```

Pour restaurer les données :
```bash
# Restauration de la base de données
cat backup.sql | docker exec -i mariadb mysql -u root -p<password> wordpress

# Restauration des fichiers WordPress
docker cp ./wordpress_backup/. wordpress:/var/www/html/
```

## Extensions possibles (Bonus)

### Redis Cache
- Amélioration des performances WordPress
- Mise en cache des requêtes fréquentes

### Serveur FTP
- Accès direct aux fichiers WordPress
- Facilite la gestion des thèmes et plugins

### Site Web Statique
- Site vitrine indépendant de WordPress
- Technologie au choix (hors PHP)

### Adminer
- Interface d'administration de base de données
- Alternative légère à phpMyAdmin

### Service supplémentaire
- Possibilité d'ajouter un service personnalisé
- Justification de son utilité requise
