# Guide d'installation et d'utilisation du projet Inception

## Table des matières
1. [Introduction](#introduction)
2. [Prérequis](#prérequis)
3. [Installation](#installation)
4. [Utilisation](#utilisation)
5. [Architecture](#architecture)
6. [Dépannage](#dépannage)
7. [Bonus](#bonus)

## Introduction

Ce projet, nommé "Inception", est un exercice d'administration système qui consiste à mettre en place une infrastructure de services à l'aide de Docker Compose. L'objectif est de créer une mini-infrastructure virtualisée composée de plusieurs services interconnectés : NGINX, WordPress et MariaDB, chacun fonctionnant dans son propre conteneur.

## Prérequis

- Debian Bullseye (ou autre distribution Linux compatible)
- Docker et Docker Compose installés
- Accès root ou sudo pour certaines opérations
- Au moins 1 Go de RAM et 5 Go d'espace disque disponible

## Installation

### 1. Cloner le dépôt

```bash
git clone <URL_DU_DEPOT> inception
cd inception
```

### 2. Configurer les variables d'environnement

Modifiez le fichier `srcs/.env` selon vos besoins :

```bash
# Exemple de configuration
nano srcs/.env
```

Assurez-vous de personnaliser au minimum les éléments suivants :
- `DOMAIN_NAME` : votre nom de domaine
- Les mots de passe pour MariaDB et WordPress

### 3. Créer les répertoires pour les volumes persistants

```bash
sudo mkdir -p /home/data/mariadb /home/data/wordpress
sudo chmod 777 /home/data/mariadb /home/data/wordpress
```

### 4. Construire et démarrer les conteneurs

```bash
make
```

Cette commande va construire et démarrer tous les conteneurs définis dans le docker-compose.yml.

### 5. Vérifier l'installation

```bash
make ps
```

Tous les services (nginx, mariadb, wordpress) doivent être en état "running".

## Utilisation

### Accès à WordPress

Une fois l'installation terminée, vous pouvez accéder à votre site WordPress via :

```
https://votre_domaine.fr
```

Remplacez `votre_domaine.fr` par la valeur définie dans `DOMAIN_NAME` dans votre fichier `.env`.

**Note importante** : Comme nous utilisons un certificat SSL auto-signé, votre navigateur affichera probablement un avertissement de sécurité. Vous pouvez l'ignorer en toute sécurité pour cet environnement de développement.

### Connexion à l'administration WordPress

Utilisez les identifiants définis dans votre fichier `.env` :
- Utilisateur : valeur de `WORDPRESS_ADMIN_USER`
- Mot de passe : valeur de `WORDPRESS_ADMIN_PASSWORD`

### Gestion des conteneurs

- Démarrer les conteneurs : `make up`
- Arrêter les conteneurs : `make down`
- Nettoyer (arrêter et supprimer les conteneurs) : `make clean`
- Nettoyage complet (conteneurs, images, volumes) : `make fclean`
- Redémarrer les conteneurs : `make re`
- Afficher les logs : `make logs`

## Architecture

L'architecture du projet est composée de trois services principaux, chacun dans son propre conteneur :

1. **NGINX** :
   - Seul point d'entrée de l'infrastructure (port 443)
   - Utilise TLS 1.2/1.3 pour les connexions sécurisées
   - Redirige les requêtes vers le service WordPress

2. **WordPress** :
   - Utilise PHP-FPM pour le traitement des fichiers PHP
   - Stocke les fichiers du site dans un volume persistant

3. **MariaDB** :
   - Base de données pour WordPress
   - Stocke les données dans un volume persistant

Les services sont connectés via un réseau Docker dédié, et les données sont persistantes grâce à des volumes montés.

## Dépannage

### Problèmes courants

1. **Erreur de connexion à la base de données**
   - Vérifiez que le service MariaDB est bien démarré : `docker ps | grep mariadb`
   - Vérifiez les variables d'environnement dans le fichier `.env`

2. **Erreur d'accès à WordPress**
   - Vérifiez que tous les services sont en cours d'exécution : `make ps`
   - Vérifiez les logs NGINX : `docker logs nginx`

3. **Certificat SSL non reconnu**
   - C'est normal, nous utilisons un certificat auto-signé
   - Ajoutez une exception de sécurité dans votre navigateur

### Réinitialisation

Si vous rencontrez des problèmes majeurs, vous pouvez réinitialiser complètement l'installation :

```bash
make fclean
sudo rm -rf /home/data/mariadb/* /home/data/wordpress/*
make
```

## Bonus

Le projet peut être étendu avec les fonctionnalités bonus suivantes :

1. **Redis cache pour WordPress**
   - Améliore les performances du site

2. **Serveur FTP**
   - Permet l'accès aux fichiers WordPress via FTP

3. **Site web statique**
   - Un site web simple en HTML/CSS/JS

4. **Adminer**
   - Interface web pour la gestion de la base de données

5. **Service supplémentaire**
   - Un service additionnel utile pour l'infrastructure

Pour activer ces bonus, consultez la documentation spécifique à chaque service dans le dossier `srcs/requirements/bonus/`.
