#!/bin/bash

# Script d'initialisation de la base de données MariaDB pour WordPress

# Attendre que le service MariaDB soit prêt
until mysqladmin ping -h"localhost" --silent; do
    echo "En attente du démarrage de MariaDB..."
    sleep 1
done

# Création de la base de données et des utilisateurs
mysql -u root << EOF
-- Sécurisation de l'installation
ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASSWORD}';
DELETE FROM mysql.user WHERE User='';
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
FLUSH PRIVILEGES;

-- Création de la base de données WordPress
CREATE DATABASE IF NOT EXISTS ${MYSQL_DATABASE};
CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'%' IDENTIFIED BY '${MYSQL_PASSWORD}';
GRANT ALL PRIVILEGES ON ${MYSQL_DATABASE}.* TO '${MYSQL_USER}'@'%';
FLUSH PRIVILEGES;
EOF

echo "Base de données MariaDB initialisée avec succès !"
