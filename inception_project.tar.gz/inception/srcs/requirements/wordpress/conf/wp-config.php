<?php
/**
 * Configuration de base pour WordPress
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d'installation. Vous n'avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations ** //
/** Nom de la base de données de WordPress */
define('DB_NAME', getenv('WORDPRESS_DB_NAME'));

/** Utilisateur de la base de données MySQL */
define('DB_USER', getenv('WORDPRESS_DB_USER'));

/** Mot de passe de la base de données MySQL */
define('DB_PASSWORD', getenv('WORDPRESS_DB_PASSWORD'));

/** Adresse de l'hôte MySQL */
define('DB_HOST', getenv('WORDPRESS_DB_HOST'));

/** Jeu de caractères à utiliser par la base de données */
define('DB_CHARSET', 'utf8');

/** Type de collation de la base de données */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d'authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clés secrètes de WordPress.org}
 */
define('AUTH_KEY',         'put your unique phrase here');
define('SECURE_AUTH_KEY',  'put your unique phrase here');
define('LOGGED_IN_KEY',    'put your unique phrase here');
define('NONCE_KEY',        'put your unique phrase here');
define('AUTH_SALT',        'put your unique phrase here');
define('SECURE_AUTH_SALT', 'put your unique phrase here');
define('LOGGED_IN_SALT',   'put your unique phrase here');
define('NONCE_SALT',       'put your unique phrase here');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 */
$table_prefix = getenv('WORDPRESS_TABLE_PREFIX');

/**
 * Pour les développeurs : le mode débogage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l'affichage des
 * notifications d'erreurs pendant vos essais.
 * Il est fortement recommandé que les développeurs d'extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 */
define('WP_DEBUG', getenv('WORDPRESS_DEBUG') === '1');

/* C'est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
