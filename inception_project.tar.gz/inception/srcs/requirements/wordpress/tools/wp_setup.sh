#!/bin/bash

# Script d'installation et de configuration de WordPress

# Attendre que la base de données soit prête
echo "Attente de la disponibilité de la base de données..."
while ! mysqladmin ping -h"$WORDPRESS_DB_HOST" --silent; do
    sleep 1
done

# Vérifier si WordPress est déjà installé
if [ ! -f /var/www/html/wp-config.php ]; then
    echo "Configuration de WordPress..."
    
    # Télécharger WP-CLI
    curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
    chmod +x wp-cli.phar
    mv wp-cli.phar /usr/local/bin/wp
    
    # Installer WordPress
    cd /var/www/html
    wp core install --url="https://$DOMAIN_NAME" \
                   --title="Inception WordPress" \
                   --admin_user="$WORDPRESS_ADMIN_USER" \
                   --admin_password="$WORDPRESS_ADMIN_PASSWORD" \
                   --admin_email="$WORDPRESS_ADMIN_EMAIL" \
                   --skip-email \
                   --allow-root
    
    # Configurer les permaliens
    wp option update permalink_structure '/%postname%/' --allow-root
    
    echo "WordPress installé avec succès !"
else
    echo "WordPress est déjà configuré."
fi

# Démarrer PHP-FPM en premier plan
echo "Démarrage de PHP-FPM..."
exec php-fpm7.4 -F
