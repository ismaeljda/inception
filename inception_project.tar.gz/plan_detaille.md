# Plan détaillé du projet Inception

## 1. Structure du projet

### 1.1 Arborescence des dossiers
```
./
├── Makefile
├── secrets/
│   ├── credentials.txt
│   ├── db_password.txt
│   └── db_root_password.txt
└── srcs/
    ├── docker-compose.yml
    ├── .env
    └── requirements/
        ├── bonus/
        │   ├── redis/
        │   │   ├── conf/
        │   │   ├── Dockerfile
        │   │   └── tools/
        │   ├── ftp/
        │   │   ├── conf/
        │   │   ├── Dockerfile
        │   │   └── tools/
        │   ├── static_site/
        │   │   ├── conf/
        │   │   ├── Dockerfile
        │   │   └── tools/
        │   ├── adminer/
        │   │   ├── conf/
        │   │   ├── Dockerfile
        │   │   └── tools/
        │   └── service_bonus/
        │       ├── conf/
        │       ├── Dockerfile
        │       └── tools/
        ├── mariadb/
        │   ├── conf/
        │   │   └── my.cnf
        │   ├── Dockerfile
        │   ├── .dockerignore
        │   └── tools/
        │       └── init_db.sh
        ├── nginx/
        │   ├── conf/
        │   │   └── nginx.conf
        │   ├── Dockerfile
        │   ├── .dockerignore
        │   └── tools/
        │       └── ssl_setup.sh
        ├── tools/
        └── wordpress/
            ├── conf/
            │   └── wp-config.php
            ├── Dockerfile
            ├── .dockerignore
            └── tools/
                └── wp_setup.sh
```

### 1.2 Fichiers principaux
- **Makefile**: Commandes pour construire, démarrer, arrêter et nettoyer l'infrastructure
- **.env**: Variables d'environnement pour la configuration des services
- **docker-compose.yml**: Configuration des services, volumes et réseaux

## 2. Implémentation des services

### 2.1 NGINX
- Image de base: Alpine ou Debian Bullseye
- Configuration TLS 1.2/1.3
- Génération de certificats SSL auto-signés
- Configuration de la redirection vers WordPress
- Exposition uniquement du port 443

### 2.2 MariaDB
- Image de base: Alpine ou Debian Bullseye
- Configuration sécurisée de la base de données
- Scripts d'initialisation pour créer la base WordPress
- Volume persistant pour les données

### 2.3 WordPress
- Image de base: Alpine ou Debian Bullseye
- Installation et configuration de PHP-FPM
- Configuration de WordPress
- Volume persistant pour les fichiers du site

## 3. Configuration Docker

### 3.1 Réseau
- Création d'un réseau Docker dédié
- Configuration des connexions entre services

### 3.2 Volumes
- Volume pour la base de données MariaDB
- Volume pour les fichiers WordPress

### 3.3 Sécurité
- Utilisation de variables d'environnement via .env
- Stockage sécurisé des mots de passe dans le dossier secrets
- Configuration des Docker secrets

## 4. Bonus (optionnels)

### 4.1 Redis Cache
- Configuration de Redis pour WordPress
- Intégration avec le service WordPress

### 4.2 Serveur FTP
- Configuration d'un serveur FTP pointant vers le volume WordPress
- Gestion des accès sécurisés

### 4.3 Site Web Statique
- Création d'un site web simple (HTML/CSS/JS)
- Configuration du serveur pour le site statique

### 4.4 Adminer
- Installation et configuration d'Adminer
- Sécurisation de l'accès

### 4.5 Service Bonus Supplémentaire
- Sélection et justification d'un service utile
- Implémentation et configuration

## 5. Documentation

### 5.1 Guide d'installation
- Prérequis système
- Procédure d'installation pas à pas
- Configuration initiale

### 5.2 Guide d'utilisation
- Accès aux différents services
- Gestion des conteneurs
- Dépannage courant

### 5.3 Architecture
- Diagramme d'architecture
- Description des interactions entre services
- Justification des choix techniques

## 6. Livrables finaux
- Structure complète du projet
- Fichiers de configuration pour tous les services
- Documentation détaillée
- Makefile fonctionnel
