#include "../include/Server.hpp"
#include <iostream>
#include <sstream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <algorithm>

// Route implementation
Route::Route() : directoryListing(false) {}

Route::Route(const std::string& path) : path(path), directoryListing(false) {}

Route::~Route() {}

const std::string& Route::getPath() const {
    return path;
}

const std::set<std::string>& Route::getAllowedMethods() const {
    return allowedMethods;
}

const std::string& Route::getRoot() const {
    return root;
}

bool Route::isDirectoryListingEnabled() const {
    return directoryListing;
}

const std::string& Route::getDefaultFile() const {
    return defaultFile;
}

const std::string& Route::getRedirectUrl() const {
    return redirectUrl;
}

const std::string& Route::getUploadDir() const {
    return uploadDir;
}

const std::string& Route::getCgiExtension() const {
    return cgiExtension;
}

void Route::setPath(const std::string& path) {
    this->path = path;
}

void Route::addAllowedMethod(const std::string& method) {
    allowedMethods.insert(method);
}

void Route::setRoot(const std::string& root) {
    this->root = root;
}

void Route::setDirectoryListing(bool enabled) {
    this->directoryListing = enabled;
}

void Route::setDefaultFile(const std::string& file) {
    this->defaultFile = file;
}

void Route::setRedirectUrl(const std::string& url) {
    this->redirectUrl = url;
}

void Route::setUploadDir(const std::string& dir) {
    this->uploadDir = dir;
}

void Route::setCgiExtension(const std::string& ext) {
    this->cgiExtension = ext;
}

// ServerConfig implementation
ServerConfig::ServerConfig() : port(80), clientMaxBodySize(1024 * 1024) {} // Default 1MB

ServerConfig::~ServerConfig() {}

const std::string& ServerConfig::getHost() const {
    return host;
}

int ServerConfig::getPort() const {
    return port;
}

const std::vector<std::string>& ServerConfig::getServerNames() const {
    return serverNames;
}

const std::map<int, std::string>& ServerConfig::getErrorPages() const {
    return errorPages;
}

size_t ServerConfig::getClientMaxBodySize() const {
    return clientMaxBodySize;
}

const std::vector<Route>& ServerConfig::getRoutes() const {
    return routes;
}

void ServerConfig::setHost(const std::string& host) {
    this->host = host;
}

void ServerConfig::setPort(int port) {
    this->port = port;
}

void ServerConfig::addServerName(const std::string& name) {
    serverNames.push_back(name);
}

void ServerConfig::addErrorPage(int code, const std::string& page) {
    errorPages[code] = page;
}

void ServerConfig::setClientMaxBodySize(size_t size) {
    clientMaxBodySize = size;
}

void ServerConfig::addRoute(const Route& route) {
    routes.push_back(route);
}

const Route* ServerConfig::findRoute(const std::string& path) const {
    // Find the most specific route that matches the path
    const Route* bestMatch = nullptr;
    size_t bestMatchLength = 0;

    for (size_t i = 0; i < routes.size(); ++i) {
        const Route& route = routes[i];
        const std::string& routePath = route.getPath();
        
        // Check if the route path is a prefix of the requested path
        if (path.find(routePath) == 0) {
            // If this route is more specific than our current best match, use it
            if (routePath.length() > bestMatchLength) {
                bestMatch = &route;
                bestMatchLength = routePath.length();
            }
        }
    }

    return bestMatch;
}

// ConfigParser implementation
ConfigParser::ConfigParser() {}

ConfigParser::~ConfigParser() {}

std::vector<ServerConfig> ConfigParser::parseConfig(const std::string& configFile) {
    std::vector<ServerConfig> configs;
    // TODO: Implement config file parsing
    // This is a placeholder for the actual parsing logic
    
    // Create a default configuration for testing
    ServerConfig defaultConfig;
    defaultConfig.setHost("0.0.0.0");
    defaultConfig.setPort(8080);
    defaultConfig.addServerName("localhost");
    defaultConfig.setClientMaxBodySize(1024 * 1024); // 1MB
    
    // Add default error pages
    defaultConfig.addErrorPage(404, "/errors/404.html");
    defaultConfig.addErrorPage(500, "/errors/500.html");
    
    // Add a default route
    Route defaultRoute("/");
    defaultRoute.addAllowedMethod("GET");
    defaultRoute.addAllowedMethod("POST");
    defaultRoute.addAllowedMethod("DELETE");
    defaultRoute.setRoot("/home/ubuntu/webserv/www");
    defaultRoute.setDefaultFile("index.html");
    defaultRoute.setDirectoryListing(true);
    defaultConfig.addRoute(defaultRoute);
    
    // Add a route for CGI
    Route cgiRoute("/cgi-bin");
    cgiRoute.addAllowedMethod("GET");
    cgiRoute.addAllowedMethod("POST");
    cgiRoute.setRoot("/home/ubuntu/webserv/www/cgi-bin");
    cgiRoute.setCgiExtension(".php");
    defaultConfig.addRoute(cgiRoute);
    
    // Add a route for uploads
    Route uploadRoute("/upload");
    uploadRoute.addAllowedMethod("POST");
    uploadRoute.setRoot("/home/ubuntu/webserv/www/upload");
    uploadRoute.setUploadDir("/home/ubuntu/webserv/www/upload");
    defaultConfig.addRoute(uploadRoute);
    
    configs.push_back(defaultConfig);
    
    return configs;
}

// HttpRequest implementation
HttpRequest::HttpRequest() : complete(false), chunked(false), contentLength(0) {}

HttpRequest::~HttpRequest() {}

const std::string& HttpRequest::getMethod() const {
    return method;
}

const std::string& HttpRequest::getUri() const {
    return uri;
}

const std::string& HttpRequest::getHttpVersion() const {
    return httpVersion;
}

const std::map<std::string, std::string>& HttpRequest::getHeaders() const {
    return headers;
}

const std::string& HttpRequest::getHeader(const std::string& name) const {
    static const std::string empty;
    auto it = headers.find(name);
    return it != headers.end() ? it->second : empty;
}

const std::string& HttpRequest::getBody() const {
    return body;
}

bool HttpRequest::isComplete() const {
    return complete;
}

bool HttpRequest::isChunked() const {
    return chunked;
}

size_t HttpRequest::getContentLength() const {
    return contentLength;
}

bool HttpRequest::parse(const std::string& data) {
    // TODO: Implement proper HTTP request parsing
    // This is a simplified version for demonstration
    
    std::istringstream iss(data);
    std::string line;
    
    // Parse request line
    if (std::getline(iss, line) && !line.empty()) {
        // Remove carriage return if present
        if (line[line.length() - 1] == '\r') {
            line = line.substr(0, line.length() - 1);
        }
        
        std::istringstream lineStream(line);
        lineStream >> method >> uri >> httpVersion;
    }
    
    // Parse headers
    while (std::getline(iss, line) && !line.empty()) {
        // Remove carriage return if present
        if (line[line.length() - 1] == '\r') {
            line = line.substr(0, line.length() - 1);
        }
        
        // Empty line indicates end of headers
        if (line.empty()) {
            break;
        }
        
        size_t colonPos = line.find(':');
        if (colonPos != std::string::npos) {
            std::string name = line.substr(0, colonPos);
            std::string value = line.substr(colonPos + 1);
            
            // Trim leading and trailing whitespace from value
            value.erase(0, value.find_first_not_of(" \t"));
            value.erase(value.find_last_not_of(" \t") + 1);
            
            headers[name] = value;
        }
    }
    
    // Check for chunked encoding
    auto transferEncodingIt = headers.find("Transfer-Encoding");
    if (transferEncodingIt != headers.end() && transferEncodingIt->second == "chunked") {
        chunked = true;
    } else {
        // Check for Content-Length
        auto contentLengthIt = headers.find("Content-Length");
        if (contentLengthIt != headers.end()) {
            contentLength = std::stoul(contentLengthIt->second);
        }
    }
    
    // Parse body
    std::string bodyStr;
    char c;
    while (iss.get(c)) {
        bodyStr += c;
    }
    
    if (chunked) {
        return parseChunkedBody(bodyStr);
    } else {
        body = bodyStr;
        complete = body.length() >= contentLength;
    }
    
    return complete;
}

bool HttpRequest::parseChunkedBody(const std::string& data) {
    // TODO: Implement chunked encoding parsing
    // This is a placeholder for the actual implementation
    
    // For simplicity, we'll just store the raw data for now
    body = data;
    complete = true;
    
    return complete;
}

// HttpResponse implementation
HttpResponse::HttpResponse() : httpVersion("HTTP/1.1"), statusCode(200), statusMessage("OK") {}

HttpResponse::~HttpResponse() {}

const std::string& HttpResponse::getHttpVersion() const {
    return httpVersion;
}

int HttpResponse::getStatusCode() const {
    return statusCode;
}

const std::string& HttpResponse::getStatusMessage() const {
    return statusMessage;
}

const std::map<std::string, std::string>& HttpResponse::getHeaders() const {
    return headers;
}

const std::string& HttpResponse::getBody() const {
    return body;
}

void HttpResponse::setHttpVersion(const std::string& version) {
    httpVersion = version;
}

void HttpResponse::setStatusCode(int code) {
    statusCode = code;
    
    // Set default status message based on code
    switch (code) {
        case 200: statusMessage = "OK"; break;
        case 201: statusMessage = "Created"; break;
        case 204: statusMessage = "No Content"; break;
        case 301: statusMessage = "Moved Permanently"; break;
        case 302: statusMessage = "Found"; break;
        case 400: statusMessage = "Bad Request"; break;
        case 403: statusMessage = "Forbidden"; break;
        case 404: statusMessage = "Not Found"; break;
        case 405: statusMessage = "Method Not Allowed"; break;
        case 413: statusMessage = "Payload Too Large"; break;
        case 500: statusMessage = "Internal Server Error"; break;
        case 501: statusMessage = "Not Implemented"; break;
        case 505: statusMessage = "HTTP Version Not Supported"; break;
        default: statusMessage = "Unknown"; break;
    }
}

void HttpResponse::setStatusMessage(const std::string& message) {
    statusMessage = message;
}

void HttpResponse::addHeader(const std::string& name, const std::string& value) {
    headers[name] = value;
}

void HttpResponse::setBody(const std::string& body) {
    this->body = body;
    
    // Update Content-Length header
    addHeader("Content-Length", std::to_string(body.length()));
}

std::string HttpResponse::toString() const {
    std::ostringstream oss;
    
    // Status line
    oss << httpVersion << " " << statusCode << " " << statusMessage << "\r\n";
    
    // Headers
    for (const auto& header : headers) {
        oss << header.first << ": " << header.second << "\r\n";
    }
    
    // Empty line separating headers from body
    oss << "\r\n";
    
    // Body
    oss << body;
    
    return oss.str();
}

// Client implementation
Client::Client(int fd) : fd(fd), keepAlive(true) {}

Client::~Client() {
    close(fd);
}

int Client::getFd() const {
    return fd;
}

HttpRequest& Client::getRequest() {
    return request;
}

HttpResponse& Client::getResponse() {
    return response;
}

std::string& Client::getBuffer() {
    return buffer;
}

bool Client::isKeepAlive() const {
    return keepAlive;
}

void Client::setKeepAlive(bool keep) {
    keepAlive = keep;
}

// Server implementation
Server::Server() {}

Server::~Server() {
    // Close all server sockets
    for (int serverSocket : serverSockets) {
        close(serverSocket);
    }
    
    // Delete all clients
    for (auto& pair : clients) {
        delete pair.second;
    }
}

bool Server::loadConfig(const std::string& configFile) {
    ConfigParser parser;
    configs = parser.parseConfig(configFile);
    
    return !configs.empty();
}

void Server::setupServerSockets() {
    for (const auto& config : configs) {
        int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
        if (serverSocket < 0) {
            std::cerr << "Error creating socket" << std::endl;
            continue;
        }
        
        // Set socket to non-blocking mode
        int flags = fcntl(serverSocket, F_GETFL, 0);
        fcntl(serverSocket, F_SETFL, flags | O_NONBLOCK);
        
        // Allow address reuse
        int opt = 1;
        setsockopt(serverSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        // Bind socket to address and port
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(config.getPort());
        
        if (config.getHost() == "localhost" || config.getHost() == "127.0.0.1") {
            serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        } else if (config.getHost() == "0.0.0.0") {
            serverAddr.sin_addr.s_addr = INADDR_ANY;
        } else {
            serverAddr.sin_addr.s_addr = inet_addr(config.getHost().c_str());
        }
        
        if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
            std::cerr << "Error binding socket to " << config.getHost() << ":" << config.getPort() << std::endl;
            close(serverSocket);
            continue;
        }
        
        // Start listening for connections
        if (listen(serverSocket, 10) < 0) {
            std::cerr << "Error listening on socket" << std::endl;
            close(serverSocket);
            continue;
        }
        
        std::cout << "Server listening on " << config.getHost() << ":" << config.getPort() << std::endl;
        
        // Add server socket to list
        serverSockets.push_back(serverSocket);
        
        // Add server socket to poll list
        struct pollfd pfd;
        pfd.fd = serverSocket;
        pfd.events = POLLIN;
        pollfds.push_back(pfd);
    }
}

void Server::acceptNewConnection(int serverSocket) {
    struct sockaddr_in clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    
    int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
    if (clientSocket < 0) {
        if (errno != EAGAIN && errno != EWOULDBLOCK) {
            std::cerr << "Error accepting connection" << std::endl;
        }
        return;
    }
    
    // Set client socket to non-blocking mode
    int flags = fcntl(clientSocket, F_GETFL, 0);
    fcntl(clientSocket, F_SETFL, flags | O_NONBLOCK);
    
    // Create new client
    Client* client = new Client(clientSocket);
    clients[clientSocket] = client;
    
    // Add client socket to poll list
    struct pollfd pfd;
    pfd.fd = clientSocket;
    pfd.events = POLLIN;
    pollfds.push_back(pfd);
    
    std::cout << "New connection from " << inet_ntoa(clientAddr.sin_addr) << ":" << ntohs(clientAddr.sin_port) << std::endl;
}

void Server::handleClientRequest(int clientFd) {
    Client* client = clients[clientFd];
    if (!client) {
        return;
    }
    
    char buffer[4096];
    ssize_t bytesRead = recv(clientFd, buffer, sizeof(buffer) - 1, 0);
    
    if (bytesRead <= 0) {
        if (bytesRead == 0 || (errno != EAGAIN && errno != EWOULDBLOCK)) {
            // Connection closed or error
            removeClient(clientFd);
        }
        return;
    }
    
    buffer[bytesRead] = '\0';
    client->getBuffer() += buffer;
    
    // Try to parse the request
    if (client->getRequest().parse(client->getBuffer())) {
        // Request is complete, process it
        const HttpRequest& request = client->getRequest();
        
        // Find the appropriate server config
        const ServerConfig* config = findServerConfig(request.getHeader("Host"), 8080); // Default port for now
        if (!config) {
            // Use the first config as default
            config = &configs[0];
        }
        
        // Process the request and generate a response
        HttpResponse response = processRequest(request, *config);
        client->getResponse() = response;
        
        // Check if we should keep the connection alive
        const std::string& connection = request.getHeader("Connection");
        if (connection == "close" || request.getHttpVersion() != "HTTP/1.1") {
            client->setKeepAlive(false);
        }
        
        // Update poll events to include POLLOUT
        for (size_t i = 0; i < pollfds.size(); ++i) {
            if (pollfds[i].fd == clientFd) {
                pollfds[i].events |= POLLOUT;
                break;
            }
        }
    }
}

void Server::handleClientResponse(int clientFd) {
    Client* client = clients[clientFd];
    if (!client) {
        return;
    }
    
    const HttpResponse& response = client->getResponse();
    std::string responseStr = response.toString();
    
    ssize_t bytesSent = send(clientFd, responseStr.c_str(), responseStr.length(), 0);
    
    if (bytesSent <= 0) {
        if (errno != EAGAIN && errno != EWOULDBLOCK) {
            // Error sending response
            removeClient(clientFd);
        }
        return;
    }
    
    // If we're not keeping the connection alive, close it
    if (!client->isKeepAlive()) {
        removeClient(clientFd);
        return;
    }
    
    // Reset client state for next request
    client->getBuffer().clear();
    client->getRequest() = HttpRequest();
    client->getResponse() = HttpResponse();
    
    // Update poll events to remove POLLOUT
    for (size_t i = 0; i < pollfds.size(); ++i) {
        if (pollfds[i].fd == clientFd) {
            pollfds[i].events = POLLIN;
            break;
        }
    }
}

void Server::removeClient(int clientFd) {
    // Remove client from poll list
    for (size_t i = 0; i < pollfds.size(); ++i) {
        if (pollfds[i].fd == clientFd) {
            pollfds.erase(pollfds.begin() + i);
            break;
        }
    }
    
    // Delete client
    delete clients[clientFd];
    clients.erase(clientFd);
}

const ServerConfig* Server::findServerConfig(const std::string& host, int port) const {
    // Extract hostname from Host header (remove port if present)
    std::string hostname = host;
    size_t colonPos = hostname.find(':');
    if (colonPos != std::string::npos) {
        hostname = hostname.substr(0, colonPos);
    }
    
    // Find config with matching host, port, and server_name
    for (const auto& config : configs) {
        if (config.getPort() == port) {
            // Check if hostname matches any server_name
            const std::vector<std::string>& serverNames = config.getServerNames();
            for (const auto& name : serverNames) {
                if (hostname == name) {
                    return &config;
                }
            }
        }
    }
    
    // Find default config for this port (first one defined)
    for (const auto& config : configs) {
        if (config.getPort() == port) {
            return &config;
        }
    }
    
    return nullptr;
}

HttpResponse Server::processRequest(const HttpRequest& request, const ServerConfig& config) {
    HttpResponse response;
    
    // Find the appropriate route
    const Route* route = config.findRoute(request.getUri());
    if (!route) {
        // No route found, return 404
        response.setStatusCode(404);
        response.setBody("<html><body><h1>404 Not Found</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Check if method is allowed
    const std::set<std::string>& allowedMethods = route->getAllowedMethods();
    if (allowedMethods.find(request.getMethod()) == allowedMethods.end()) {
        // Method not allowed, return 405
        response.setStatusCode(405);
        response.setBody("<html><body><h1>405 Method Not Allowed</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        
        // Add Allow header with allowed methods
        std::string allowHeader;
        for (const auto& method : allowedMethods) {
            if (!allowHeader.empty()) {
                allowHeader += ", ";
            }
            allowHeader += method;
        }
        response.addHeader("Allow", allowHeader);
        
        return response;
    }
    
    // Check for redirect
    if (!route->getRedirectUrl().empty()) {
        response.setStatusCode(301);
        response.addHeader("Location", route->getRedirectUrl());
        return response;
    }
    
    // Handle request based on method
    if (request.getMethod() == "GET") {
        return handleGetRequest(request, config, *route);
    } else if (request.getMethod() == "POST") {
        return handlePostRequest(request, config, *route);
    } else if (request.getMethod() == "DELETE") {
        return handleDeleteRequest(request, config, *route);
    } else {
        // Method not implemented
        response.setStatusCode(501);
        response.setBody("<html><body><h1>501 Not Implemented</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
}

HttpResponse Server::handleGetRequest(const HttpRequest& request, const ServerConfig& config, const Route& route) {
    HttpResponse response;
    
    // Get the file path
    std::string uri = request.getUri();
    std::string routePath = route.getPath();
    std::string filePath = route.getRoot();
    
    // If URI is exactly the route path, append default file if set
    if (uri == routePath && !route.getDefaultFile().empty()) {
        uri += "/" + route.getDefaultFile();
    }
    
    // Append the relative path to the root
    if (uri.length() > routePath.length()) {
        filePath += uri.substr(routePath.length());
    }
    
    // Check if this is a CGI request
    std::string extension = filePath.substr(filePath.find_last_of('.') + 1);
    if (!route.getCgiExtension().empty() && route.getCgiExtension() == "." + extension) {
        return executeCgi(request, filePath);
    }
    
    // Check if file exists
    struct stat fileStat;
    if (stat(filePath.c_str(), &fileStat) < 0) {
        // File not found
        response.setStatusCode(404);
        
        // Check if custom error page exists
        const std::map<int, std::string>& errorPages = config.getErrorPages();
        auto it = errorPages.find(404);
        if (it != errorPages.end()) {
            // Try to serve custom error page
            std::string errorPagePath = route.getRoot() + it->second;
            std::ifstream errorFile(errorPagePath);
            if (errorFile) {
                std::string errorContent((std::istreambuf_iterator<char>(errorFile)), std::istreambuf_iterator<char>());
                response.setBody(errorContent);
                response.addHeader("Content-Type", "text/html");
                return response;
            }
        }
        
        // Use default error page
        response.setBody("<html><body><h1>404 Not Found</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Check if it's a directory
    if (S_ISDIR(fileStat.st_mode)) {
        // Check if default file exists
        if (!route.getDefaultFile().empty()) {
            std::string defaultFilePath = filePath + "/" + route.getDefaultFile();
            std::ifstream defaultFile(defaultFilePath);
            if (defaultFile) {
                // Serve default file
                std::string content((std::istreambuf_iterator<char>(defaultFile)), std::istreambuf_iterator<char>());
                response.setBody(content);
                
                // Set Content-Type based on file extension
                std::string extension = defaultFilePath.substr(defaultFilePath.find_last_of('.') + 1);
                if (extension == "html" || extension == "htm") {
                    response.addHeader("Content-Type", "text/html");
                } else if (extension == "css") {
                    response.addHeader("Content-Type", "text/css");
                } else if (extension == "js") {
                    response.addHeader("Content-Type", "application/javascript");
                } else if (extension == "jpg" || extension == "jpeg") {
                    response.addHeader("Content-Type", "image/jpeg");
                } else if (extension == "png") {
                    response.addHeader("Content-Type", "image/png");
                } else if (extension == "gif") {
                    response.addHeader("Content-Type", "image/gif");
                } else {
                    response.addHeader("Content-Type", "application/octet-stream");
                }
                
                return response;
            }
        }
        
        // Check if directory listing is enabled
        if (route.isDirectoryListingEnabled()) {
            // Generate directory listing
            std::string listing = generateDirectoryListing(filePath, uri);
            response.setBody(listing);
            response.addHeader("Content-Type", "text/html");
            return response;
        } else {
            // Directory listing not allowed
            response.setStatusCode(403);
            response.setBody("<html><body><h1>403 Forbidden</h1></body></html>");
            response.addHeader("Content-Type", "text/html");
            return response;
        }
    }
    
    // Serve the file
    std::ifstream file(filePath, std::ios::binary);
    if (!file) {
        // Error opening file
        response.setStatusCode(500);
        response.setBody("<html><body><h1>500 Internal Server Error</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Read file content
    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    response.setBody(content);
    
    // Set Content-Type based on file extension
    std::string extension = filePath.substr(filePath.find_last_of('.') + 1);
    if (extension == "html" || extension == "htm") {
        response.addHeader("Content-Type", "text/html");
    } else if (extension == "css") {
        response.addHeader("Content-Type", "text/css");
    } else if (extension == "js") {
        response.addHeader("Content-Type", "application/javascript");
    } else if (extension == "jpg" || extension == "jpeg") {
        response.addHeader("Content-Type", "image/jpeg");
    } else if (extension == "png") {
        response.addHeader("Content-Type", "image/png");
    } else if (extension == "gif") {
        response.addHeader("Content-Type", "image/gif");
    } else {
        response.addHeader("Content-Type", "application/octet-stream");
    }
    
    return response;
}

HttpResponse Server::handlePostRequest(const HttpRequest& request, const ServerConfig& config, const Route& route) {
    HttpResponse response;
    
    // Check if body size exceeds limit
    if (request.getBody().length() > config.getClientMaxBodySize()) {
        response.setStatusCode(413);
        response.setBody("<html><body><h1>413 Payload Too Large</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Check if this is a CGI request
    std::string uri = request.getUri();
    std::string routePath = route.getPath();
    std::string filePath = route.getRoot();
    
    // Append the relative path to the root
    if (uri.length() > routePath.length()) {
        filePath += uri.substr(routePath.length());
    }
    
    std::string extension = filePath.substr(filePath.find_last_of('.') + 1);
    if (!route.getCgiExtension().empty() && route.getCgiExtension() == "." + extension) {
        return executeCgi(request, filePath);
    }
    
    // Check if this is an upload request
    if (!route.getUploadDir().empty()) {
        // TODO: Implement file upload handling
        // This is a placeholder for the actual implementation
        
        response.setStatusCode(201);
        response.setBody("<html><body><h1>201 Created</h1><p>File uploaded successfully.</p></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Default POST response
    response.setStatusCode(200);
    response.setBody("<html><body><h1>200 OK</h1><p>POST request processed.</p></body></html>");
    response.addHeader("Content-Type", "text/html");
    return response;
}

HttpResponse Server::handleDeleteRequest(const HttpRequest& request, const ServerConfig& config, const Route& route) {
    HttpResponse response;
    
    // Get the file path
    std::string uri = request.getUri();
    std::string routePath = route.getPath();
    std::string filePath = route.getRoot();
    
    // Append the relative path to the root
    if (uri.length() > routePath.length()) {
        filePath += uri.substr(routePath.length());
    }
    
    // Check if file exists
    struct stat fileStat;
    if (stat(filePath.c_str(), &fileStat) < 0) {
        // File not found
        response.setStatusCode(404);
        response.setBody("<html><body><h1>404 Not Found</h1></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Check if it's a directory
    if (S_ISDIR(fileStat.st_mode)) {
        // Cannot delete directories
        response.setStatusCode(403);
        response.setBody("<html><body><h1>403 Forbidden</h1><p>Cannot delete directories.</p></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Delete the file
    if (unlink(filePath.c_str()) < 0) {
        // Error deleting file
        response.setStatusCode(500);
        response.setBody("<html><body><h1>500 Internal Server Error</h1><p>Error deleting file.</p></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // File deleted successfully
    response.setStatusCode(204);
    return response;
}

HttpResponse Server::executeCgi(const HttpRequest& request, const std::string& scriptPath) {
    HttpResponse response;
    
    // TODO: Implement CGI execution
    // This is a placeholder for the actual implementation
    
    response.setStatusCode(501);
    response.setBody("<html><body><h1>501 Not Implemented</h1><p>CGI execution not implemented yet.</p></body></html>");
    response.addHeader("Content-Type", "text/html");
    return response;
}

std::string Server::generateDirectoryListing(const std::string& path, const std::string& uri) {
    std::ostringstream listing;
    
    listing << "<html><head><title>Directory Listing: " << uri << "</title></head><body>";
    listing << "<h1>Directory Listing: " << uri << "</h1><hr><ul>";
    
    // Add parent directory link if not at root
    if (uri != "/") {
        std::string parentUri = uri.substr(0, uri.find_last_of('/'));
        if (parentUri.empty()) {
            parentUri = "/";
        }
        listing << "<li><a href=\"" << parentUri << "\">..</a></li>";
    }
    
    // Open directory
    DIR* dir = opendir(path.c_str());
    if (dir) {
        struct dirent* entry;
        std::vector<std::string> entries;
        
        // Read all entries
        while ((entry = readdir(dir)) != nullptr) {
            std::string name = entry->d_name;
            
            // Skip . and ..
            if (name == "." || name == "..") {
                continue;
            }
            
            entries.push_back(name);
        }
        
        closedir(dir);
        
        // Sort entries
        std::sort(entries.begin(), entries.end());
        
        // Add entries to listing
        for (const auto& name : entries) {
            std::string entryPath = path + "/" + name;
            struct stat entryStat;
            
            if (stat(entryPath.c_str(), &entryStat) >= 0) {
                std::string entryUri = uri;
                if (entryUri.back() != '/') {
                    entryUri += '/';
                }
                entryUri += name;
                
                if (S_ISDIR(entryStat.st_mode)) {
                    listing << "<li><a href=\"" << entryUri << "/\">" << name << "/</a></li>";
                } else {
                    listing << "<li><a href=\"" << entryUri << "\">" << name << "</a></li>";
                }
            }
        }
    }
    
    listing << "</ul><hr></body></html>";
    
    return listing.str();
}

void Server::run() {
    // Set up server sockets
    setupServerSockets();
    
    if (serverSockets.empty()) {
        std::cerr << "No server sockets created, exiting" << std::endl;
        return;
    }
    
    std::cout << "Server started, waiting for connections..." << std::endl;
    
    // Main event loop
    while (true) {
        // Wait for events
        int numEvents = poll(pollfds.data(), pollfds.size(), -1);
        if (numEvents < 0) {
            if (errno == EINTR) {
                // Interrupted by signal, continue
                continue;
            }
            
            std::cerr << "Error in poll()" << std::endl;
            break;
        }
        
        // Process events
        for (size_t i = 0; i < pollfds.size() && numEvents > 0; ++i) {
            if (pollfds[i].revents == 0) {
                continue;
            }
            
            --numEvents;
            
            int fd = pollfds[i].fd;
            
            // Check if this is a server socket
            bool isServerSocket = false;
            for (int serverSocket : serverSockets) {
                if (fd == serverSocket) {
                    isServerSocket = true;
                    break;
                }
            }
            
            if (isServerSocket) {
                // Accept new connection
                if (pollfds[i].revents & POLLIN) {
                    acceptNewConnection(fd);
                }
            } else {
                // Handle client socket
                if (pollfds[i].revents & POLLIN) {
                    handleClientRequest(fd);
                }
                
                if (pollfds[i].revents & POLLOUT) {
                    handleClientResponse(fd);
                }
                
                // Handle errors
                if (pollfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    removeClient(fd);
                }
            }
        }
    }
}
