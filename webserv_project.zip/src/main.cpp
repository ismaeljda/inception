#include "../include/Server.hpp"
#include <iostream>

int main(int argc, char* argv[]) {
    // Check command line arguments
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <config_file>" << std::endl;
        return 1;
    }

    // Create server
    Server server;

    // Load configuration
    if (!server.loadConfig(argv[1])) {
        std::cerr << "Error loading configuration from " << argv[1] << std::endl;
        return 1;
    }

    // Run server
    server.run();

    return 0;
}
