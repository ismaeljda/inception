#include "../include/CGI.hpp"
#include <iostream>
#include <sstream>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <cstring>

CGI::CGI(const std::string& path, const HttpRequest& request) : scriptPath(path) {
    // Extract script name and extension
    size_t lastSlash = scriptPath.find_last_of('/');
    if (lastSlash != std::string::npos) {
        scriptName = scriptPath.substr(lastSlash + 1);
    } else {
        scriptName = scriptPath;
    }
    
    size_t lastDot = scriptName.find_last_of('.');
    if (lastDot != std::string::npos) {
        scriptExtension = scriptName.substr(lastDot);
    }
    
    // Set request method
    requestMethod = request.getMethod();
    
    // Extract query string from URI if present
    std::string uri = request.getUri();
    size_t questionMark = uri.find('?');
    if (questionMark != std::string::npos) {
        queryString = uri.substr(questionMark + 1);
    }
    
    // Set request body
    requestBody = request.getBody();
    
    // Setup environment variables
    setupEnvironment(request);
}

CGI::~CGI() {}

void CGI::setupEnvironment(const HttpRequest& request) {
    // Set standard CGI environment variables
    env["GATEWAY_INTERFACE"] = "CGI/1.1";
    env["SERVER_PROTOCOL"] = request.getHttpVersion();
    env["REQUEST_METHOD"] = requestMethod;
    env["SCRIPT_NAME"] = scriptName;
    env["SCRIPT_FILENAME"] = scriptPath;
    env["PATH_INFO"] = "";
    env["PATH_TRANSLATED"] = scriptPath;
    env["QUERY_STRING"] = queryString;
    env["REMOTE_ADDR"] = "127.0.0.1"; // Placeholder
    env["SERVER_NAME"] = "localhost"; // Placeholder
    env["SERVER_PORT"] = "8080"; // Placeholder
    env["SERVER_SOFTWARE"] = "Webserv/1.0";
    
    // Set content-related variables
    if (requestMethod == "POST") {
        env["CONTENT_LENGTH"] = std::to_string(requestBody.length());
        
        // Get content type from headers
        const std::string& contentType = request.getHeader("Content-Type");
        if (!contentType.empty()) {
            env["CONTENT_TYPE"] = contentType;
        } else {
            env["CONTENT_TYPE"] = "application/x-www-form-urlencoded";
        }
    }
    
    // Set HTTP headers as environment variables
    const std::map<std::string, std::string>& headers = request.getHeaders();
    for (std::map<std::string, std::string>::const_iterator it = headers.begin(); it != headers.end(); ++it) {
        std::string name = it->first;
        std::string value = it->second;
        
        // Convert header name to CGI format (HTTP_*)
        for (size_t i = 0; i < name.length(); ++i) {
            if (name[i] == '-') {
                name[i] = '_';
            } else {
                name[i] = std::toupper(name[i]);
            }
        }
        
        env["HTTP_" + name] = value;
    }
}

HttpResponse CGI::execute() {
    HttpResponse response;
    
    // Create pipes for communication with CGI process
    int inputPipe[2]; // For sending data to CGI
    int outputPipe[2]; // For receiving data from CGI
    
    if (pipe(inputPipe) < 0 || pipe(outputPipe) < 0) {
        std::cerr << "Error creating pipes for CGI" << std::endl;
        response.setStatusCode(500);
        response.setBody("<html><body><h1>500 Internal Server Error</h1><p>Error executing CGI script.</p></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    }
    
    // Set pipes to non-blocking mode
    fcntl(inputPipe[0], F_SETFL, O_NONBLOCK);
    fcntl(inputPipe[1], F_SETFL, O_NONBLOCK);
    fcntl(outputPipe[0], F_SETFL, O_NONBLOCK);
    fcntl(outputPipe[1], F_SETFL, O_NONBLOCK);
    
    // Fork process
    pid_t pid = fork();
    
    if (pid < 0) {
        // Fork failed
        std::cerr << "Error forking process for CGI" << std::endl;
        close(inputPipe[0]);
        close(inputPipe[1]);
        close(outputPipe[0]);
        close(outputPipe[1]);
        
        response.setStatusCode(500);
        response.setBody("<html><body><h1>500 Internal Server Error</h1><p>Error executing CGI script.</p></body></html>");
        response.addHeader("Content-Type", "text/html");
        return response;
    } else if (pid == 0) {
        // Child process (CGI script)
        
        // Redirect stdin to read from inputPipe
        close(inputPipe[1]); // Close write end
        dup2(inputPipe[0], STDIN_FILENO);
        close(inputPipe[0]);
        
        // Redirect stdout to write to outputPipe
        close(outputPipe[0]); // Close read end
        dup2(outputPipe[1], STDOUT_FILENO);
        close(outputPipe[1]);
        
        // Set up environment variables
        for (std::map<std::string, std::string>::const_iterator it = env.begin(); it != env.end(); ++it) {
            setenv(it->first.c_str(), it->second.c_str(), 1);
        }
        
        // Execute CGI script
        char* args[3];
        args[0] = strdup("/usr/bin/php-cgi"); // Assuming PHP CGI
        args[1] = strdup(scriptPath.c_str());
        args[2] = NULL;
        
        execve(args[0], args, environ);
        
        // If execve returns, there was an error
        std::cerr << "Error executing CGI script: " << strerror(errno) << std::endl;
        exit(1);
    } else {
        // Parent process
        
        // Close unused pipe ends
        close(inputPipe[0]);
        close(outputPipe[1]);
        
        // Write request body to CGI script
        if (requestMethod == "POST" && !requestBody.empty()) {
            write(inputPipe[1], requestBody.c_str(), requestBody.length());
        }
        
        // Close write end of input pipe
        close(inputPipe[1]);
        
        // Read CGI output
        std::string output;
        char buffer[4096];
        ssize_t bytesRead;
        
        // Use poll to wait for data with timeout
        struct pollfd pfd;
        pfd.fd = outputPipe[0];
        pfd.events = POLLIN;
        
        // Wait for up to 30 seconds
        int timeout = 30000;
        
        while (poll(&pfd, 1, timeout) > 0) {
            if (pfd.revents & POLLIN) {
                bytesRead = read(outputPipe[0], buffer, sizeof(buffer) - 1);
                if (bytesRead <= 0) {
                    break;
                }
                
                buffer[bytesRead] = '\0';
                output += buffer;
            } else {
                break;
            }
        }
        
        // Close read end of output pipe
        close(outputPipe[0]);
        
        // Wait for child process to exit
        int status;
        waitpid(pid, &status, 0);
        
        // Check if CGI script executed successfully
        if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            // Parse CGI output to create HTTP response
            return parseOutput(output);
        } else {
            // CGI script execution failed
            std::cerr << "CGI script execution failed with status " << WEXITSTATUS(status) << std::endl;
            response.setStatusCode(500);
            response.setBody("<html><body><h1>500 Internal Server Error</h1><p>Error executing CGI script.</p></body></html>");
            response.addHeader("Content-Type", "text/html");
            return response;
        }
    }
}

HttpResponse CGI::parseOutput(const std::string& output) {
    HttpResponse response;
    
    // Split output into headers and body
    size_t headerEnd = output.find("\r\n\r\n");
    if (headerEnd == std::string::npos) {
        headerEnd = output.find("\n\n");
        if (headerEnd == std::string::npos) {
            // No header/body separation found, treat entire output as body
            response.setBody(output);
            response.addHeader("Content-Type", "text/html");
            return response;
        }
        headerEnd += 2; // Skip two newlines
    } else {
        headerEnd += 4; // Skip CRLF CRLF
    }
    
    std::string headers = output.substr(0, headerEnd);
    std::string body = output.substr(headerEnd);
    
    // Parse headers
    std::istringstream headerStream(headers);
    std::string line;
    bool statusSet = false;
    
    while (std::getline(headerStream, line)) {
        // Remove carriage return if present
        if (!line.empty() && line[line.length() - 1] == '\r') {
            line = line.substr(0, line.length() - 1);
        }
        
        // Empty line indicates end of headers
        if (line.empty()) {
            break;
        }
        
        // Check for Status header
        if (line.substr(0, 7) == "Status:") {
            std::string statusLine = line.substr(7);
            statusLine.erase(0, statusLine.find_first_not_of(" \t"));
            
            // Extract status code
            size_t spacePos = statusLine.find(' ');
            if (spacePos != std::string::npos) {
                int statusCode = std::atoi(statusLine.substr(0, spacePos).c_str());
                std::string statusMessage = statusLine.substr(spacePos + 1);
                
                response.setStatusCode(statusCode);
                response.setStatusMessage(statusMessage);
                statusSet = true;
            }
        } else {
            // Regular header
            size_t colonPos = line.find(':');
            if (colonPos != std::string::npos) {
                std::string name = line.substr(0, colonPos);
                std::string value = line.substr(colonPos + 1);
                
                // Trim leading and trailing whitespace from value
                value.erase(0, value.find_first_not_of(" \t"));
                value.erase(value.find_last_not_of(" \t") + 1);
                
                response.addHeader(name, value);
            }
        }
    }
    
    // Set default status if not set by CGI
    if (!statusSet) {
        response.setStatusCode(200);
    }
    
    // Set body
    response.setBody(body);
    
    // Set default Content-Type if not set by CGI
    if (response.getHeaders().find("Content-Type") == response.getHeaders().end()) {
        response.addHeader("Content-Type", "text/html");
    }
    
    return response;
}
