#ifndef CGI_HPP
#define CGI_HPP

#include <string>
#include <map>
#include "Server.hpp"

class CGI {
private:
    std::string scriptPath;
    std::string scriptName;
    std::string scriptExtension;
    std::string requestMethod;
    std::string queryString;
    std::string requestBody;
    std::map<std::string, std::string> env;

public:
    CGI(const std::string& path, const HttpRequest& request);
    ~CGI();

    // Execute CGI script and return response
    HttpResponse execute();

private:
    // Set up environment variables for CGI
    void setupEnvironment(const HttpRequest& request);
    
    // Parse CGI output to create HTTP response
    HttpResponse parseOutput(const std::string& output);
};

#endif // CGI_HPP
