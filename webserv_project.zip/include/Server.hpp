#ifndef SERVER_HPP
#define SERVER_HPP

#include <string>
#include <vector>
#include <map>
#include <set>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>

class Route {
private:
    std::string path;
    std::set<std::string> allowedMethods;
    std::string root;
    bool directoryListing;
    std::string defaultFile;
    std::string redirectUrl;
    std::string uploadDir;
    std::string cgiExtension;

public:
    Route();
    Route(const std::string& path);
    ~Route();

    // Getters
    const std::string& getPath() const;
    const std::set<std::string>& getAllowedMethods() const;
    const std::string& getRoot() const;
    bool isDirectoryListingEnabled() const;
    const std::string& getDefaultFile() const;
    const std::string& getRedirectUrl() const;
    const std::string& getUploadDir() const;
    const std::string& getCgiExtension() const;

    // Setters
    void setPath(const std::string& path);
    void addAllowedMethod(const std::string& method);
    void setRoot(const std::string& root);
    void setDirectoryListing(bool enabled);
    void setDefaultFile(const std::string& file);
    void setRedirectUrl(const std::string& url);
    void setUploadDir(const std::string& dir);
    void setCgiExtension(const std::string& ext);
};

class ServerConfig {
private:
    std::string host;
    int port;
    std::vector<std::string> serverNames;
    std::map<int, std::string> errorPages;
    size_t clientMaxBodySize;
    std::vector<Route> routes;

public:
    ServerConfig();
    ~ServerConfig();

    // Getters
    const std::string& getHost() const;
    int getPort() const;
    const std::vector<std::string>& getServerNames() const;
    const std::map<int, std::string>& getErrorPages() const;
    size_t getClientMaxBodySize() const;
    const std::vector<Route>& getRoutes() const;

    // Setters
    void setHost(const std::string& host);
    void setPort(int port);
    void addServerName(const std::string& name);
    void addErrorPage(int code, const std::string& page);
    void setClientMaxBodySize(size_t size);
    void addRoute(const Route& route);

    // Find route for a given path
    const Route* findRoute(const std::string& path) const;
};

class ConfigParser {
public:
    ConfigParser();
    ~ConfigParser();

    std::vector<ServerConfig> parseConfig(const std::string& configFile);
};

class HttpRequest {
private:
    std::string method;
    std::string uri;
    std::string httpVersion;
    std::map<std::string, std::string> headers;
    std::string body;
    bool complete;
    bool chunked;
    size_t contentLength;

public:
    HttpRequest();
    ~HttpRequest();

    // Getters
    const std::string& getMethod() const;
    const std::string& getUri() const;
    const std::string& getHttpVersion() const;
    const std::map<std::string, std::string>& getHeaders() const;
    const std::string& getHeader(const std::string& name) const;
    const std::string& getBody() const;
    bool isComplete() const;
    bool isChunked() const;
    size_t getContentLength() const;

    // Parsing
    bool parse(const std::string& data);
    bool parseChunkedBody(const std::string& data);
};

class HttpResponse {
private:
    std::string httpVersion;
    int statusCode;
    std::string statusMessage;
    std::map<std::string, std::string> headers;
    std::string body;

public:
    HttpResponse();
    ~HttpResponse();

    // Getters
    const std::string& getHttpVersion() const;
    int getStatusCode() const;
    const std::string& getStatusMessage() const;
    const std::map<std::string, std::string>& getHeaders() const;
    const std::string& getBody() const;

    // Setters
    void setHttpVersion(const std::string& version);
    void setStatusCode(int code);
    void setStatusMessage(const std::string& message);
    void addHeader(const std::string& name, const std::string& value);
    void setBody(const std::string& body);

    // Generate response string
    std::string toString() const;
};

class Client {
private:
    int fd;
    HttpRequest request;
    HttpResponse response;
    std::string buffer;
    bool keepAlive;

public:
    Client(int fd);
    ~Client();

    // Getters
    int getFd() const;
    HttpRequest& getRequest();
    HttpResponse& getResponse();
    std::string& getBuffer();
    bool isKeepAlive() const;

    // Setters
    void setKeepAlive(bool keep);
};

class Server {
private:
    std::vector<ServerConfig> configs;
    std::vector<int> serverSockets;
    std::vector<struct pollfd> pollfds;
    std::map<int, Client*> clients;

    // Private methods
    void setupServerSockets();
    void acceptNewConnection(int serverSocket);
    void handleClientRequest(int clientFd);
    void handleClientResponse(int clientFd);
    void removeClient(int clientFd);
    const ServerConfig* findServerConfig(const std::string& host, int port) const;
    HttpResponse processRequest(const HttpRequest& request, const ServerConfig& config);
    HttpResponse handleGetRequest(const HttpRequest& request, const ServerConfig& config, const Route& route);
    HttpResponse handlePostRequest(const HttpRequest& request, const ServerConfig& config, const Route& route);
    HttpResponse handleDeleteRequest(const HttpRequest& request, const ServerConfig& config, const Route& route);
    HttpResponse executeCgi(const HttpRequest& request, const std::string& scriptPath);
    std::string generateDirectoryListing(const std::string& path, const std::string& uri);

public:
    Server();
    ~Server();

    // Load configuration
    bool loadConfig(const std::string& configFile);

    // Run server
    void run();
};

#endif // SERVER_HPP
