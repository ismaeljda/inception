<?php
header("Content-Type: text/html; charset=UTF-8");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test CGI PHP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
        }
        h1 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Test CGI PHP</h1>
        <p>Cette page démontre le fonctionnement du CGI avec PHP.</p>
        
        <h2>Informations sur le serveur</h2>
        <p>Date et heure actuelles : <?php echo date('Y-m-d H:i:s'); ?></p>
        
        <h2>Variables d'environnement CGI</h2>
        <table>
            <tr>
                <th>Nom</th>
                <th>Valeur</th>
            </tr>
            <?php
            $env_vars = array(
                'SERVER_SOFTWARE',
                'SERVER_NAME',
                'GATEWAY_INTERFACE',
                'SERVER_PROTOCOL',
                'SERVER_PORT',
                'REQUEST_METHOD',
                'PATH_INFO',
                'PATH_TRANSLATED',
                'SCRIPT_NAME',
                'QUERY_STRING',
                'REMOTE_ADDR',
                'REMOTE_HOST',
                'CONTENT_TYPE',
                'CONTENT_LENGTH'
            );
            
            foreach ($env_vars as $var) {
                if (isset($_SERVER[$var])) {
                    echo "<tr><td>$var</td><td>" . htmlspecialchars($_SERVER[$var]) . "</td></tr>";
                }
            }
            ?>
        </table>
        
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <h2>Données POST reçues</h2>
        <table>
            <tr>
                <th>Nom</th>
                <th>Valeur</th>
            </tr>
            <?php
            foreach ($_POST as $key => $value) {
                echo "<tr><td>" . htmlspecialchars($key) . "</td><td>" . htmlspecialchars($value) . "</td></tr>";
            }
            ?>
        </table>
        <?php endif; ?>
        
        <?php if (!empty($_GET)): ?>
        <h2>Données GET reçues</h2>
        <table>
            <tr>
                <th>Nom</th>
                <th>Valeur</th>
            </tr>
            <?php
            foreach ($_GET as $key => $value) {
                echo "<tr><td>" . htmlspecialchars($key) . "</td><td>" . htmlspecialchars($value) . "</td></tr>";
            }
            ?>
        </table>
        <?php endif; ?>
    </div>
</body>
</html>
