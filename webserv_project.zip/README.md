# Projet Webserv - Documentation

## Description
Ce projet consiste en l'implémentation d'un serveur HTTP conforme aux spécifications du sujet, sans inclure la partie bonus. Le serveur est capable de gérer des requêtes HTTP, de servir des sites web statiques, d'exécuter des scripts CGI, et de gérer les uploads de fichiers.

## Fonctionnalités implémentées
- Serveur HTTP non-bloquant utilisant poll()
- Support des méthodes GET, POST et DELETE
- Configuration flexible inspirée de NGINX
- Gestion des sites web statiques
- Support des uploads de fichiers
- Exécution de CGI (PHP)
- Redirections HTTP
- Listing des répertoires

## Structure du projet
```
webserv/
├── include/           # Fichiers d'en-tête
│   ├── Server.hpp     # Définition des classes principales
│   └── CGI.hpp        # Définition de la classe CGI
├── src/               # Fichiers sources
│   ├── main.cpp       # Point d'entrée du programme
│   ├── Server.cpp     # Implémentation des classes principales
│   └── CGI.cpp        # Implémentation de la classe CGI
├── config/            # Fichiers de configuration
│   └── default.conf   # Configuration par défaut
├── www/               # Contenu web
│   ├── index.html     # Page d'accueil
│   ├── test.html      # Page de test
│   ├── errors/        # Pages d'erreur
│   │   ├── 404.html   # Page d'erreur 404
│   │   └── 500.html   # Page d'erreur 500
│   ├── upload/        # Répertoire pour les uploads
│   │   └── index.html # Page d'upload
│   └── cgi-bin/       # Scripts CGI
│       └── test.php   # Script PHP de test
├── Makefile           # Makefile pour la compilation
└── todo.md            # Liste des tâches
```

## Compilation et exécution
Pour compiler le projet, exécutez la commande suivante à la racine du projet :
```
make
```

Pour exécuter le serveur avec la configuration par défaut :
```
./webserv ./config/default.conf
```

## Configuration
Le fichier de configuration est inspiré de NGINX et permet de définir :
- Les ports et hôtes d'écoute
- Les noms de serveur (server_names)
- Les pages d'erreur par défaut
- La taille maximale des corps de requête
- Les routes avec diverses règles (méthodes autorisées, redirections, listing des répertoires, etc.)

Exemple de configuration :
```
server {
    listen 8080;
    host 0.0.0.0;
    server_name localhost;
    client_max_body_size 1M;

    error_page 404 /errors/404.html;
    error_page 500 /errors/500.html;

    location / {
        root /home/ubuntu/webserv/www;
        index index.html;
        allowed_methods GET POST DELETE;
        autoindex on;
    }

    location /cgi-bin {
        root /home/ubuntu/webserv/www/cgi-bin;
        allowed_methods GET POST;
        cgi_extension .php;
    }
}
```

## Test du serveur
Une fois le serveur démarré, vous pouvez le tester en accédant aux URLs suivantes dans votre navigateur :
- http://localhost:8080/ - Page d'accueil
- http://localhost:8080/test.html - Page de test simple
- http://localhost:8080/upload - Test d'upload de fichiers
- http://localhost:8080/cgi-bin/test.php - Test de CGI (PHP)
- http://localhost:8080/redirect - Test de redirection
- http://localhost:8080/nonexistent - Test de page d'erreur 404

## Remarques importantes
- Le serveur utilise des descripteurs de fichiers non-bloquants avec poll()
- Le serveur est compatible avec les navigateurs web standards
- Les codes de statut HTTP sont précis
- Le serveur dispose de pages d'erreur par défaut
- Le fork n'est utilisé que pour l'exécution de CGI
- Le serveur peut servir un site web statique complet
- Les clients peuvent uploader des fichiers
- Les méthodes GET, POST et DELETE sont supportées

## Limitations
- La partie bonus (cookies, sessions, multi-CGI) n'est pas implémentée, conformément à la demande
